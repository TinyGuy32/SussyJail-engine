import pygame
import os

def main():
    objects = os.listdir("objects")
    players = []
    for a in objects:
        for b in open("objects\\"+a+"\\config.txt").read().split("\n"):
            try:
                players.append([int(b.split("_")[0]),int(b.split("_")[1]),"objects\\"+a+"\\image.png",False,"objects\\"+a+"\\config.txt"])
            except:
                q = 0

    playerX = 0
    playerY = 0
    
    width=500
    height=500

    pygame.init()
    pygame.display.set_caption("WorldEngine")
    
    screen = pygame.display.set_mode((width,height))
    

    running = True
    while running:
        on = 0
        screen.fill((0,0,0))
        for a in players:
            if a[3]:
                a[0] = playerX
                a[1] = playerY
            npcX = a[0]
            npcY = a[1]
            if (npcX+width/2)-playerX>-1 and (npcX+width/2)-playerX<width and (npcY+height/2)-playerY>-1 and (npcY+height/2)-playerY<height:
                screen.blit(pygame.image.load(a[2]),((npcX+width/2)-playerX,(npcY+height/2)-playerY))
        screen.blit(pygame.image.load("images\\editor.png"),(width/2,height/2))
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type==pygame.KEYDOWN:
                if event.key == pygame.K_d:
                    playerX += 10
                    print(playerX)
                if event.key == pygame.K_a:
                    playerX -= 10
                    print(playerX)
                if event.key == pygame.K_w:
                    playerY -= 10
                    print(playerY)
                if event.key == pygame.K_s:
                    playerY += 10
                    print(playerY)
                if event.key == pygame.K_p:
                    for a in players:
                        withinBounds = playerX > a[0]-(pygame.image.load("images\\editor.png").get_width()-1) and playerX < a[0]+pygame.image.load(a[2]).get_width() and playerY > a[1]-(pygame.image.load("images\\editor.png").get_height()-1) and playerY < a[1]+pygame.image.load(a[2]).get_height()
                        if withinBounds:
                            if a[3] == False:
                                a[3] = True
                            else:
                                a[3] = False
                if event.key == pygame.K_o:
                    try:
                        inPut = input()
                        players.append([playerX,playerY,"objects\\"+inPut+"\\image.png",False,"objects\\"+inPut+"\\config.txt"])
                    except:
                        print("that object dose not exist")
                if event.key == pygame.K_i:
                    for a in players:
                        withinBounds = playerX > a[0]-(pygame.image.load("images\\editor.png").get_width()-1) and playerX < a[0]+pygame.image.load(a[2]).get_width() and playerY > a[1]-(pygame.image.load("images\\editor.png").get_height()-1) and playerY < a[1]+pygame.image.load(a[2]).get_height()
                        if withinBounds:
                            players.append([a[0],a[1],a[2],True,a[4]])
                            break
                    continue
                if event.key == pygame.K_u:
                    for a in players:
                        withinBounds = playerX > a[0]-(pygame.image.load("images\\editor.png").get_width()-1) and playerX < a[0]+pygame.image.load(a[2]).get_width() and playerY > a[1]-(pygame.image.load("images\\editor.png").get_height()-1) and playerY < a[1]+pygame.image.load(a[2]).get_height()
                        if withinBounds:
                            locationIn = 0
                            while players[locationIn] != a:
                                locationIn += 1
                            players.pop(locationIn)
            if event.type==pygame.QUIT:
                for a in objects:
                    b = open("objects\\"+a+"\\config.txt","w")
                    b.write("")
                    b.close()
                toFile = ""
                for a in players:
                    open(a[len(a)-1],"a").write(str(a[0])+"_"+str(a[1])+"\n")
                running = False
if __name__=="__main__":
    main()
