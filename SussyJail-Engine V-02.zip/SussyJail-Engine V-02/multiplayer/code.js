http = require("http")
fs = require("fs")
locations = []
ipAddresses = []
names = []
streams = []
streamNames = []

isAinB = (A,B) => {
    returnValue = false
    for(item of B) {
        if(item == A) {
            returnValue = true
        }
    }
    return returnValue
}

indexOfAinB = (A,B) => {
    on = 0
    while(B[on] != A) {
        on += 1
    }
    return on
}

writeList = (list) => {
    returnValue = ""
    on = 0
    for(element of list) {
        returnValue += element
        if(typeof list[on+1] != 'undefined') {
            returnValue += ','
        }
        on += 1
    }
    return returnValue
}
playermodel = fs.createReadStream(__dirname+"\\images\\you.png")
fs.readdir(__dirname+"\\objects\\", (err,files) => {
    for(object of files) {
        names.push(object)
        streams.push([fs.createReadStream(__dirname+"\\objects\\"+object+"\\image.png"),fs.createReadStream(__dirname+"\\objects\\"+object+"\\config.txt")])
    }
    console.log(streams)
})

http.createServer((req, res) => {
    if(isAinB(req.connection.remoteAddress,ipAddresses)) {
        if(req.url[1]=="*") {
            locations[indexOfAinB(req.connection.remoteAddress,ipAddresses)] = req.url.split("*")[1]
            res.write(writeList(locations))
            res.end()
        }
        if(req.url[1]=="_") {
            streams[indexOfAinB(req.url.split("_")[1],names)][0].pipe(res)
        }
        if(req.url[1]=="-") {
            streams[indexOfAinB(req.url.split("-")[1],names)][1].pipe(res)
        }
        if(req.url=="/playermodel") {
            playermodel.pipe(res)
        }
        if(req.url=="/getobjects") {
            res.end(writeList(names))
        }
    }
    else {
        ipAddresses.push(req.connection.remoteAddress)
        locations.push([0,0])
        res.end(writeList(locations))
    }
}).listen(6969)