import pygame
import requests
import os

ip = input("enter the ip of the server you are tryibng to connect to:")
requests.get(ip+"/*0_0")

def main():

    playerX = 0
    playerY = 0
    
    width=500
    height=500

    pygame.init()
    pygame.display.set_caption("WorldEngine")
    
    screen = pygame.display.set_mode((width,height))
    image = requests.get(ip+"/_wall1").content
    print(image)
    file = open("downloaded\\wall1.png","wb")
    file.write(image)
    file.close()
    a = "downloaded\\wall1.png"
    running = True
    while running:
        for event in pygame.event.get():
            screen.blit(pygame.image.load(a),(0,0))
            pygame.display.flip()
            if event.type==pygame.QUIT:
                running = False
def close():
    for a in os.listdir("downloaded"):
        os.remove("downloaded\\"+a)
    pass
if __name__=="__main__":
    main()
    close()
