print("amongus")
