print("if")
