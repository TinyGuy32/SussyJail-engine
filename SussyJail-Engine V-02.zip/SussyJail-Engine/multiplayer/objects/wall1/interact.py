print("a")
