import pygame
import os
import sys
import requests

ip = input("server ip:")
requests.get(ip+"/*0_0")
def closeGame():
    for a in os.listdir("downloaded"):
        os.remove("downloaded\\"+a+"\\image.png")
        os.remove("downloaded\\"+a+"\\config.txt")
        os.rmdir("downloaded\\"+a)
def main():
    downloadNames = requests.get(ip+"/getobjects").text.split(",")
    for objectName in downloadNames:
        os.mkdir("downloaded\\"+objectName)
        downloadFile = open("downloaded\\"+objectName+"\\image.png","wb")
        downloadFile.write(requests.get(ip+"/_"+objectName).content)
        downloadFile.close()
        downloadFile = open("downloaded\\"+objectName+"\\config.txt","wb")
        downloadFile.write(requests.get(ip+"/-"+objectName).content)
        downloadFile.close()
    objects = os.listdir("downloaded")
    # the variable players dose not store player locations, it stores the locations of the objects
    players = []
    # the variable playerLocations will store the locations of the players
    for a in objects:
        for b in open("downloaded\\"+a+"\\config.txt").read().split("\n"):
            try:
                players.append([int(b.split("_")[0]),int(b.split("_")[1]),"downloaded\\"+a+"\\image.png"])
            except:
                q=0

    playerX = 0
    playerY = 0
    
    width=500
    height=500

    pygame.init()
    pygame.display.set_caption("WorldEngine")
    
    screen = pygame.display.set_mode((width,height))

    Direction = [False,False,False,False]

    running = True
    while running:
        playerList = []
        #sending the info to the server and getting the player locations
        list1 = requests.get(ip+"/*"+str(playerX)+","+str(playerY)).text.split(",")
        on = 0
        while on<len(list1)-1:
            playerList.append([int(list1[on]),int(list1[on+1])])
            on+=2
        on = 0
        screen.fill((0,0,0))
        for a in playerList:
            npcX = a[0]
            npcY = a[1]
            #an algorithim to figure out what objects to render and where
            if (npcX+width/2)-playerX>-1 and (npcX+width/2)-playerX<width and (npcY+height/2)-playerY>-1 and (npcY+height/2)-playerY<height:
                screen.blit(pygame.image.load("images\\you.png"),((npcX+width/2)-playerX,(npcY+height/2)-playerY))
        for a in players:
            npcX = a[0]
            npcY = a[1]
            #an algorithim to figure out what objects to render and where
            if (npcX+width/2)-playerX>-1 and (npcX+width/2)-playerX<width and (npcY+height/2)-playerY>-1 and (npcY+height/2)-playerY<height:
                screen.blit(pygame.image.load(a[2]),((npcX+width/2)-playerX,(npcY+height/2)-playerY))
        screen.blit(pygame.image.load("images\\you.png"),(width/2,height/2))
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type==pygame.KEYDOWN:
                if event.key == pygame.K_d:
                    Direction[3] = True
                    print(playerX)
                if event.key == pygame.K_a:
                    Direction[1] = True
                    print(playerX)
                if event.key == pygame.K_w:
                    Direction[0] = True
                    print(playerY)
                if event.key == pygame.K_s:
                    Direction[2] = True
                    print(playerY)
            if event.type==pygame.KEYUP:
                if event.key == pygame.K_w:
                    Direction[0] = False
                if event.key == pygame.K_a:
                    Direction[1] = False
                if event.key == pygame.K_s:
                    Direction[2] = False
                if event.key == pygame.K_d:
                    Direction[3] = False
            if event.type==pygame.QUIT:
                running = False
        if Direction[0]:
            playerY -= 5
            for a in players:
                withinBounds = playerX > a[0]-(pygame.image.load("images\\you.png").get_width()-1) and playerX < a[0]+pygame.image.load(a[2]).get_width() and playerY > a[1]-(pygame.image.load("images\\you.png").get_height()-1) and playerY < a[1]+pygame.image.load(a[2]).get_height()
                if withinBounds:
                    playerY += 5
        if Direction[1]:
            playerX -= 5
            for a in players:
                withinBounds = playerX > a[0]-(pygame.image.load("images\\you.png").get_width()-1) and playerX < a[0]+pygame.image.load(a[2]).get_width() and playerY > a[1]-(pygame.image.load("images\\you.png").get_height()-1) and playerY < a[1]+pygame.image.load(a[2]).get_height()
                if withinBounds:
                    playerX += 5
        if Direction[2]:
            playerY += 5
            for a in players:
                withinBounds = playerX > a[0]-(pygame.image.load("images\\you.png").get_width()-1) and playerX < a[0]+pygame.image.load(a[2]).get_width() and playerY > a[1]-(pygame.image.load("images\\you.png").get_height()-1) and playerY < a[1]+pygame.image.load(a[2]).get_height()
                if withinBounds:
                    playerY -= 5
        if Direction[3]:
            playerX += 5
            for a in players:
                withinBounds = playerX > a[0]-(pygame.image.load("images\\you.png").get_width()-1) and playerX < a[0]+pygame.image.load(a[2]).get_width() and playerY > a[1]-(pygame.image.load("images\\you.png").get_height()-1) and playerY < a[1]+pygame.image.load(a[2]).get_height()
                if withinBounds:
                    playerX -= 5
if __name__=="__main__":
    main()
    closeGame()
